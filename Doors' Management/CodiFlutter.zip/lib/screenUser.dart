import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart'; // Importa el paquete de image_picker
import 'dart:io';
import 'data.dart';

class ScreenUser extends StatefulWidget {
  User user;

  ScreenUser({super.key, required this.user});

  @override
  State<ScreenUser> createState() => _ScreenUserState();
}

class _ScreenUserState extends State<ScreenUser> {
  String? _imagePath = 'faces/eva.png';
  late ImageProvider imageAvatar;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    imageAvatar = AssetImage(Data.images.containsKey(widget.user.name.toLowerCase())
        ? Data.images[widget.user.name.toLowerCase()]!
        : Data.images["new user"]!) as ImageProvider;
  }

  Future<void> _selectImage() async {

    final ImagePicker picker = ImagePicker();

    // Abre la galería para seleccionar una imagen
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _imagePath = pickedFile.path;
        imageAvatar = FileImage(File(_imagePath!));
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final TextEditingController nameController = TextEditingController();
    final TextEditingController credentialController = TextEditingController();
    nameController.text = widget.user.name;
    credentialController.text = widget.user.credential;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        title: Text('User'),
      ),
      body: Center(
        child: GridView.count(
          crossAxisCount: 1,
          padding: const EdgeInsets.all(16.0),
          children: [
            Container(
              child: Column(
                children: [
                  ElevatedButton(
                    style: ElevatedButton.styleFrom( shape: const CircleBorder(),),
                    onPressed: () { _selectImage(); },
                    child: CircleAvatar( radius: 150, foregroundImage: imageAvatar,

                    ),
                  ),
                  SizedBox(height: 16),
                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(
                      labelText: 'Name',
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 1,
                  ),
                  SizedBox(height: 8),
                  TextField(
                    controller: credentialController,
                    decoration: InputDecoration(
                      labelText: 'Credential',
                      border: OutlineInputBorder(),
                    ),
                    maxLines: 1,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: SizedBox(
                      width: 150,
                      height: 40,
                      child: ElevatedButton(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Saved')),
                          );
                          widget.user.name = nameController.text;
                          widget.user.credential = credentialController.text;
                          setState(() { });
                        },
                        child: Text('Submit'),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}