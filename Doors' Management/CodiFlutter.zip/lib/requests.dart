import 'package:http/http.dart' as http;
import 'dart:convert' as convert;
import 'Utils.dart' as utils;

import 'tree.dart';

//Function to obtain the whole tree of the building from the root (building)
Future<Tree> getTree(String areaId) async {
  //const String BASE_URL = "https://b04e-158-109-94-92.ngrok-free.app";
  const String BASE_URL = "http://localhost:8080";
  Uri uri = Uri.parse("${BASE_URL}/get_children?$areaId");
  final response = await http.get(uri);
  // response is NOT a Future because of await
  if (response.statusCode == 200) {
    // TODO: change prints by logs, use package Logger for instance
    // which is the most popular, see https://pub.dev/packages/logger
    print("statusCode=$response.statusCode");
    print(response.body);
    // If the server did return a 200 OK response, then parse the JSON.
    Map<String, dynamic> decoded = convert.jsonDecode(response.body);
    return Tree(decoded);
  } else {
    // If the server did not return a 200 OK response, then throw an exception.
    print("statusCode=$response.statusCode");
    throw Exception('failed to get answer to request $uri');
  }
}

//This function is used to make door actions, such as locking it, unlocking it,
// closing it or opening it. This function just works with the leafs of the tree (doors)
Future<bool> makeAction(String doorId, String action) async {
  //const String BASE_URL = "https://b04e-158-109-94-92.ngrok-free.app";
  const String BASE_URL = "http://localhost:8080";
  String dataActual = utils.getData();
  Uri uri = Uri.parse("${BASE_URL}/reader?credential=11343&action=$action&datetime=$dataActual&doorId=$doorId");
  final response = await http.get(uri);

  if (response.statusCode == 200) {
    // TODO: change prints by logs, use package Logger for instance
    print("statusCode=$response.statusCode");
    print(response.body);
    print("Entra a makeAction");
    return true;
  } else {
    // If the server did not return a 200 OK response, then throw an exception.
    print("statusCode=$response.statusCode");
    throw Exception('failed to get answer to request $uri');
  }
}

//Function used to make requests from a whole area (space or partition). With it, areas
//can be locked or unlocked, including their children in the tree and so on.
Future<bool> requestArea(String areaId, String action) async {
  //const String BASE_URL = "https://b04e-158-109-94-92.ngrok-free.app";
  const String BASE_URL = "http://localhost:8080";
  String dataActual = utils.getData();
  Uri uri = Uri.parse("${BASE_URL}/area?credential=11343&action=$action&datetime=$dataActual&areaId=$areaId");
  final response = await http.get(uri);

  if (response.statusCode == 200) {
    // TODO: change prints by logs, use package Logger for instance
    print("statusCode=$response.statusCode");
    print(response.body);
    print("Entra a requestArea");
    return true;
  } else {
    // If the server did not return a 200 OK response, then throw an exception.
    print("statusCode=$response.statusCode");
    throw Exception('failed to get answer to request $uri');
  }
}