import 'package:flutter/material.dart';
import 'package:weekday_selector/weekday_selector.dart';
import 'data.dart';
import 'generated/l10n.dart';
import 'the_drawer.dart';
import 'screenGroupInfo.dart';

class ScreenSchedule extends StatefulWidget {
  UserGroup userGroup;

  ScreenSchedule({super.key, required this.userGroup});

  @override
  State<ScreenSchedule> createState() => _ScreenScheduleState();
}

class _ScreenScheduleState extends State<ScreenSchedule> {
  late List<UserGroup> userGroups;
  late List<bool> selected = [false, false, false, false, false, false, false];
  late DateTime _fromDate;
  late DateTime _toDate;
  late TimeOfDay _fromTime;
  late TimeOfDay _toTime;

  @override
  void initState() {
    super.initState();
    for(int i = 1; i <= 7; i++) {
      if(widget.userGroup.schedule.weekdays.contains(i)) {
        if(i == 7) {
          selected[0] = true;
        }
        else {
          selected[i] = true;
        }
      }
    }

    _fromTime = widget.userGroup.schedule.fromTime;
    _toTime = widget.userGroup.schedule.toTime;
    _fromDate = widget.userGroup.schedule.fromDate;
    _toDate = widget.userGroup.schedule.toDate;
  }

  Future<void> _selectDate(BuildContext context, bool isFromDate) async {
    DateTime initialDate = isFromDate ? _fromDate : _toDate;
    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2027),
    );

    if (picked != null && picked != initialDate) {
      setState(() {
        if (isFromDate) {
          _fromDate = picked;
        } else {
          _toDate = picked;
        }

        if(_fromDate.isAfter(_toDate)) {
          _toDate = _fromDate;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(S.of(context).wrongDate)),
          );
        }
      });
    }
  }

  int _timeToMinutes(TimeOfDay time) {
    return time.hour * 60 + time.minute;
  }

  Future<void> _selectTime(BuildContext context, bool isFromTime) async {
    TimeOfDay initialTime = isFromTime ? _fromTime : _toTime;
    TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: initialTime,
    );

    if (picked != null && picked != initialTime) {
      setState(() {
        if (isFromTime) {
          _fromTime = picked;
        } else {
          _toTime = picked;
        }

        if(_timeToMinutes(_fromTime) > _timeToMinutes(_toTime)) {
          _toTime = _fromTime;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(S.of(context).wrongHour)),
          );
        }
      });
    }
  }

  String _formatDate(DateTime date) {
    // Using the basic datetime of DateTime
    return "${date.month}/${date.day}/${date.year}";
  }

  String _formatTime(TimeOfDay time) {
    // Using the basic pattern of TimeOfDay
    return '${time.hour}:${time.minute.toString().padLeft(2, '0')}';
  }



  void _handleWeekdayChanged(int index) {
    setState(() {
      if(index == 7)
        index = 0;
      selected[index] = !selected[index];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: Theme.of(context).colorScheme.primary,
            foregroundColor: Theme.of(context).colorScheme.onPrimary,
            title: Text('${S.of(context).schedule} ${widget.userGroup.name}')
        ),
        body: Center(
            child: Column(
              //padding: const EdgeInsets.all(16.0),
                children: [
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(child: Text(S.of(context).from)),
                        Text(_formatDate(_fromDate)),
                        IconButton(onPressed: () => _selectDate(context, true), icon:  Icon(Icons.calendar_month, size:20))
                      ]),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(child: Text(S.of(context).to)),
                        Text(_formatDate(_toDate)),
                        IconButton(onPressed: () => _selectDate(context, false), icon:  Icon(Icons.calendar_month, size:20))
                      ]),
                  Column(
                    children: [
                      Text(S.of(context).weekdays),
                      WeekdaySelector(
                        onChanged: _handleWeekdayChanged,
                        values: selected,
                        shortWeekdays: defaultShortWeekdays,
                      )
                    ],
                  ),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(child: Text(S.of(context).from)),
                        Text(_formatTime(_fromTime)),
                        IconButton(onPressed: () => _selectTime(context, true), icon:  Icon(Icons.schedule, size:20))
                      ]),
                  Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(child: Text(S.of(context).to)),
                        Text(_formatTime(_toTime)),
                        IconButton(onPressed: () => _selectTime(context, false), icon:  Icon(Icons.schedule, size:20))
                      ]),
                  Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: SizedBox(
                      width: 150,
                      height: 40,
                      child: ElevatedButton(
                        onPressed: () {
                          widget.userGroup.schedule.weekdays.clear();
                          for(int i = 0; i < 7; i++) {
                            if(i == 0 && selected[i]) {
                              widget.userGroup.schedule.weekdays.add(7);
                            } else if ( selected[i]) {
                              widget.userGroup.schedule.weekdays.add(i);
                            }
                          }
                          widget.userGroup.schedule.fromTime = _fromTime;
                          widget.userGroup.schedule.toTime = _toTime;
                          widget.userGroup.schedule.fromDate = _fromDate;
                          widget.userGroup.schedule.toDate = _toDate;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(S.of(context).saved)),
                          );
                          /*widget.userGroup.name = nameController.text; //Cambiar para poner hora y dia actualizado
                              widget.userGroup.description = descriptionController.text;
                              setState(() { });
                              */
                        },
                        child: Text(S.of(context).submit),
                      ),
                    ),
                  )
                ]
            )
        )
    );
  }
}