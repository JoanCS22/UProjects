import 'package:flutter/material.dart';
import 'data.dart';
import 'screenUser.dart';
import 'generated/l10n.dart';

class ScreenListUsers extends StatefulWidget {
  UserGroup userGroup;

  ScreenListUsers({super.key, required this.userGroup});

  @override
  State<ScreenListUsers> createState() => _ScreenListUsersState();
}

class _ScreenListUsersState extends State<ScreenListUsers> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.add),
        onPressed: () {
          widget.userGroup.users.add(User("new user", "id"));
          setState(() {});
        },
      ),
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        title: Text(S.of(context).users),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16.0),
        itemCount: widget.userGroup.users.length,
        itemBuilder: (BuildContext context, int index) =>
            _buildRow(widget.userGroup.users[index], index),
        separatorBuilder: (BuildContext context, int index) => const Divider(),
      ),
    );
  }

  Widget _buildRow(User user, int index) {
    return ListTile(
      leading: CircleAvatar(foregroundImage: AssetImage(
          Data.images.containsKey(user.name.toLowerCase())
              ? Data.images[user.name.toLowerCase()]!
              : Data.images["new user"]!) as ImageProvider,) ,
      title: Text(user.name == 'new user' ? S.of(context).newUser : user.name),
      trailing: Text('${user.credential}'),
      onTap: () {Navigator.of(context).push(
          MaterialPageRoute<void>(
              builder: (context) => ScreenUser(user: user)
          )
      ).then((var v) => setState(() {}));},
    );
  }
}
