import 'package:flutter/material.dart';
import 'generated/l10n.dart';
import 'tree.dart';
import 'requests.dart';
import 'screen_partition.dart';

//Class that creates the screen for areas named as Spaces. These screens are formed by
//an appbar containing the state of the Space, and then a list of doors which are the
//children of the current space. These doors have their state and whether they are closed or not
class ScreenSpace extends StatefulWidget {
  final String id;
  const ScreenSpace({super.key, required this.id});

  @override
  State<ScreenSpace> createState() => _StateScreenSpace();
}

class _StateScreenSpace extends State<ScreenSpace> {
  //late Tree tree;
  late Future<Tree> futureTree;
  @override
  void initState() {
    super.initState();
    futureTree = getTree(widget.id);
  }

  //Function to update the tree after making any request with
  // any of the doors
  void _refreshTree() {
    setState(() {
      futureTree = getTree(widget.id);
    });
  }

  // Function to verify if every door from this space is locked
  bool _isSpaceLocked(Tree tree) {
    return tree.root.children.every((door) => door.state == "locked");
  }

  // Function to translate the state para el estado de la puerta
  String getLocalizedState(BuildContext context, String state) {
    var localizedStates = {
      'locked': S.of(context).lockedName,
      'unlocked': S.of(context).unlockedName,
    };
    return localizedStates[state] ?? state;
  }

  // Function for booleans (now just for closed true/false)
  String getLocalizedBool(BuildContext context, bool value) {
    return value ? S.of(context).trueName : S.of(context).falseName;
  }

  //Function that shows a SnackBar at the bottom of the screen when a
  //door is tried to be closed/opened or locked/unlocked.
  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2), // Duración de 2 segundos
      ),
    );
  }

  //This function creates every door item in the list forming the screen
  Widget _buildRow(Door door, int index) {
    return ListTile(
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('${S.of(context).doorSymbol} ${door.id}'), // Título
          Row(
            children: [
              // Button that represents the state locked or unlocked of the door,
              // by its attribute "state"
              IconButton(
                icon: Icon(door.state == "locked" ? Icons.lock : Icons.lock_open),
                onPressed: () async {
                  var message = S.of(context).errorAction;
                  if (door.state == "locked") {
                    await makeAction(door.id, "unlock");
                    if(door.closed) {
                      message = S.of(context).doorUnlocked;
                    }
                  } else {
                    await makeAction(door.id, "lock");
                    if(door.closed) {
                      message = S.of(context).doorLocked;
                    }
                  }
                  _showSnackBar(message);
                  _refreshTree();
                },
              ),
              SizedBox(width: 8),
              // Button that represents the state open or closed of the door,
              // by its attribute "closed"
              IconButton(
                icon: Icon(Icons.door_front_door, color: door.closed ? Colors.red: Colors.green),
                onPressed: () async {
                  var message = S.of(context).errorAction;
                  if (door.closed) {
                    await makeAction(door.id, "open");
                    if(door.state == "unlocked") {
                      message = S.of(context).doorOpened;
                    }
                  } else {
                    await makeAction(door.id, "close");
                    if(door.state == "unlocked") {
                      message = S.of(context).doorClosed;
                    }
                  }
                  _showSnackBar(message);
                  _refreshTree(); // Actualiza el árbol
                },
              ),
            ],
          ),
        ],
      ),
      trailing: Text('${getLocalizedState(context, door.state)}, '
          '${getLocalizedBool(context, door.closed)}'), 
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Tree>(
      future: futureTree,
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          final tree = snapshot.data!;
          final isSpaceLocked = _isSpaceLocked(tree);

          return Scaffold(
            appBar: AppBar(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
              title: Text(tree.root.id),
              actions: <Widget>[
                IconButton(
                  icon: Icon(isSpaceLocked ? Icons.lock : Icons.lock_open),
                  onPressed: () async {
                    // Send an area request to lock/unlock every door in the space
                    if (isSpaceLocked) {
                      await requestArea(tree.root.id, "unlock");
                    } else {
                      await requestArea(tree.root.id, "lock");
                    }
                    _refreshTree();
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.home),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (context) => const ScreenPartition(id: "building"),
                      ),
                    );
                  },
                ),
              ],
            ),
            body: ListView.separated(
              padding: const EdgeInsets.all(16.0),
              itemCount: tree.root.children.length,
              itemBuilder: (BuildContext context, int i) =>
                  _buildRow(tree.root.children[i], i),
              separatorBuilder: (BuildContext context, int index) =>
              const Divider(),
            ),
          );
        } else if (snapshot.hasError) {
          return Text("${snapshot.error}");
        }

        return Container(
          height: MediaQuery.of(context).size.height,
          color: Colors.white,
          child: const Center(
            child: CircularProgressIndicator(),
          ),
        );
      },
    );
  }
}