import 'package:flutter/material.dart';
import 'generated/l10n.dart';
import 'tree.dart';
import 'screen_space.dart';
import 'requests.dart';

//Class that implement and create the screen of partitions.
//These include information about the state, the names of the areas,
//among others.
class ScreenPartition extends StatefulWidget {
  final String id;
  const ScreenPartition({super.key, required this.id});

  @override
  State<ScreenPartition> createState() => _ScreenPartitionState();
}

class _ScreenPartitionState extends State<ScreenPartition> {
  late Future<Tree> futureTree;


  @override
  void initState() {
    super.initState();
    futureTree = getTree(widget.id);
  }

  //Function to update the tree after making any request with
  // any of the doors
  void _refreshTree() {
    setState(() {
      futureTree = getTree(widget.id);
    });
  }

  // Verifies if a partition is locked
  bool _isPartitionLocked(Tree tree) {
    bool locked = _areAllDescendantsLocked(tree.root);
    print(locked);
    return locked;
  }

  // Recusrive function that verifies if all descendants (children) are locked
  bool _areAllDescendantsLocked(Area area) {
    if (area is Space) {
      // A space without doors is considered as locked
      return area.children.isEmpty || area.children.every((door) => door.state == "locked");
    }

    if (area is Partition) {
      return area.children.every((child) => child is Area && _areAllDescendantsLocked(child)
      );
    }

    return false;
  }

  // Function to obtain the name of the area translated
  String getLocalizedName(BuildContext context, String key) {
    var localizedNames = {
    'building': S.of(context).building,
    'basement': S.of(context).basement,
    'ground_floor': S.of(context).ground_floor,
    'floor1': S.of(context).floor1,
    'stairs': S.of(context).stairs,
    'exterior': S.of(context).exterior,
    'parking': S.of(context).parking,
    'hall': S.of(context).hall,
    'room1': S.of(context).room1,
    'room2': S.of(context).room2,
    'room3': S.of(context).room3,
    'corridor': S.of(context).corridor,
    'IT': S.of(context).IT,
    };
  return localizedNames[key] ?? key; // Si no encuentra la clave, devuelve el propio ID.
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Tree>(
      future: futureTree,
      builder: (context, snapshot) {
        // anonymous function
        if (snapshot.hasData) {
          final tree = snapshot.data!;
          final isPartitionLocked = _isPartitionLocked(tree);

          return Scaffold(
            appBar: AppBar(
              backgroundColor: Theme.of(context).colorScheme.primary,
              foregroundColor: Theme.of(context).colorScheme.onPrimary,
              title: Text(snapshot.data!.root.id),
              actions: <Widget>[
                IconButton(
                  //Building the appbar, we use a lock to show if a partition is locked or not
                  icon: Icon(isPartitionLocked ? Icons.lock : Icons.lock_open),
                  onPressed: () async {
                    if(isPartitionLocked) {
                      await requestArea(tree.root.id, "unlock");
                    } else {
                      await requestArea(tree.root.id, "lock");
                    }

                    _refreshTree();
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.home),
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (context) => const ScreenPartition(id: "building"),
                      ),
                    );
                  },
                ),
              ],
            ),
            body: Column(
              children: [
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16.0),
                    itemCount: snapshot.data!.root.children.length,
                    //By implementing this, every child of the current partition is built
                    itemBuilder: (BuildContext context, int i) =>
                        _buildRow(snapshot.data!.root.children[i], i),
                    separatorBuilder: (BuildContext context, int index) =>
                    const Divider(),
                  ),
                ),
                if (widget.id == "building")
                  //If the current area is the building, we put some buttons to implement l18n
                  //and then l10n, with 3 different locales: spanish, catalan and english.
                  //Therefore, if you click any od these buttons, the app is automatically translated
                  //to the language you have chosen.
                  Container(
                    padding: const EdgeInsets.all(8.0),
                    color: Colors.grey[200],
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () {
                            setState(() { S.load(const Locale('ca','ES')); });
                            } ,
                          child: Text(S.of(context).buildingPageCatalan),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            setState(() { S.load(const Locale('es','ES')); });
                          } ,
                          child: Text(S.of(context).buildingPageSpanish),
                        ),
                        ElevatedButton(
                          onPressed: () {
                            setState(() { S.load(const Locale('en','GB')); });
                          } ,
                          child: Text(S.of(context).buildingPageEnglish),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          );
        } else if (snapshot.hasError) {
          return Text("${snapshot.error}");
        }
        // By default, show a progress indicator
        return Container(
            height: MediaQuery.of(context).size.height,
            color: Colors.white,
            child: Center(
              child: CircularProgressIndicator(),
            ));
      },
    );
  }

  //Function to create every child of the current area with the symbol (space or partition)
  //and the name
  Widget _buildRow(Area area, int index) {
    var currentArea = area.id;
    assert (area is Partition || area is Space);
    if (area is Partition) {
      return ListTile(
        title: Text('${S.of(context).partitionSymbol} ${getLocalizedName(context, currentArea)}'),
        onTap: () => _navigateDownPartition(area.id),
      );
    } else {
      return ListTile(
        title: Text('${S.of(context).spaceSymbol} ${getLocalizedName(context, currentArea)}'),
        onTap: () => _navigateDownSpace(area.id),
      );
    }
  }

  //Function used to go to next level of the tree if it is a partition
  void _navigateDownPartition(String childId) {
    Navigator.of(context)
        .push(MaterialPageRoute<void>(builder: (context) => ScreenPartition(id: childId,))
    );
  }

  //Function used to go to next level of the tree if it is a space with doors
  void _navigateDownSpace(String childId) {
    Navigator.of(context)
        .push(MaterialPageRoute<void>(builder: (context) => ScreenSpace(id: childId,))
    );
  }
}
