import 'package:flutter/material.dart';
import 'the_drawer.dart';
import 'generated/l10n.dart';
class ScreenBlank extends StatefulWidget {

  const ScreenBlank({super.key});

  @override
  State<ScreenBlank> createState() => _ScreenBlankState();
}

class _ScreenBlankState extends State<ScreenBlank> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: TheDrawer(context).drawer,
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        title: Text("ACS"),
      ),
      body: Container(
        padding: const EdgeInsets.all(8.0),
        color: Colors.grey[200],
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            ElevatedButton(
              onPressed: () {
                setState(() { S.load(const Locale('ca','ES')); });
              } ,
              child: Text(S.of(context).buildingPageCatalan),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() { S.load(const Locale('es','ES')); });
              } ,
              child: Text(S.of(context).buildingPageSpanish),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() { S.load(const Locale('en','GB')); });
              } ,
              child: Text(S.of(context).buildingPageEnglish),
            ),
          ],
        ),
      ),
    );
  }
}