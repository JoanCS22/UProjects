import 'package:flutter/material.dart';
import 'data.dart';
import 'generated/l10n.dart';

class ScreenListActions extends StatefulWidget {
  late UserGroup userGroup;

  ScreenListActions({super.key, required this.userGroup});

  @override
  State<ScreenListActions> createState() => _ScreenListActionsState();
}

class _ScreenListActionsState extends State<ScreenListActions> {
  late List<bool> isChecked = [true, true, false, false, false];
  @override
  void initState() {
    super.initState();
    for(int i = 0; i < widget.userGroup.actions.length; i++) {
      isChecked[i] = widget.userGroup.checked[i];
    }
  }
  // Function to obtain the name of the area translated
  String getActionName(BuildContext context, String key) {
    var localizedNames = {
      'open': S.of(context).open,
      'close': S.of(context).close,
      'lock': S.of(context).lock,
      'unlock': S.of(context).unlock,
      'unlock_shortly': S.of(context).unlock_shortly,
    };
    return localizedNames[key] ?? key; // Si no encuentra la clave, devuelve el propio ID.
  }
  // Function to obtain the name of the area translated
  String getActionDescription(BuildContext context, String key) {
    var localizedNames = {
      'Opens an unlocked door': S.of(context).open_description,
      'Closes an open door': S.of(context).close_description,
      'Locks a door or all the doors in a room or group of rooms, if closed': S.of(context).lock_description,
      'Unlocks a locked door or all the locked doors in an room': S.of(context).unlock_description,
      'Unlocks a door during 10 seconds and the locks it if it is closed': S.of(context).unlock_shortly_description,
    };
    return localizedNames[key] ?? key; // Si no encuentra la clave, devuelve el propio ID.
  }

  List<Widget> _buildActionList() {
    List<Widget> widgets = [];
    for (int i = 0; i < widget.userGroup.actions.length; i++) {
      widgets.add(
        CheckboxListTile(
          title: Text( getActionName(context, widget.userGroup.actions[i]), style: TextStyle(fontSize: 25)),
          subtitle: Text( getActionDescription(context, widget.userGroup.areasDescription[i]) , style: TextStyle(fontSize: 20)),
          value: isChecked[i], // Estado actual
          onChanged: (bool? newValue) {
            setState(() {
              isChecked[i] = newValue ?? false; // Actualizar estado
            });
          },
        ),
      );
      widgets.add(Divider());
    }
    widgets.add(
      Padding(
        padding: const EdgeInsets.all(18.0),
        child: ElevatedButton(
          child: Text(S.of(context).submit),
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(S.of(context).saved)),
            );
            for(int i = 0; i < widget.userGroup.actions.length; i++) {
              widget.userGroup.checked[i] = isChecked[i];
            }
          },
        ),
      ),
    );
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Theme.of(context).colorScheme.onPrimary,
        title: Text(S.of(context).actions),
      ),
      body: Column(
        children: _buildActionList(),
      ),
    );
  }

}

