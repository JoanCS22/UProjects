import 'package:flutter/material.dart';


class Actions {
  static const String open = "open";
  static const String close = "close";
  static const String lock = "lock";
  static const String unlock = "unlock";
  static const String unlockShortly = "unlock_shortly";
  static List<String> all = <String>[open, close, lock, unlock, unlockShortly];
// not const because we will assign it to some groups and later can be change
// in the screen of actions
}

class User {
  late String name;
  late String credential;

  User(this.name, this.credential);
}

class Schedule {
  late List<int> weekdays; // DateTime.monday==1, DateTime.sunday==7
  late DateTime fromDate;
  late DateTime toDate;
  late TimeOfDay fromTime;
  late TimeOfDay toTime;

  Schedule(this.weekdays, this.fromDate, this.toDate, this.fromTime, this.toTime);
}

class UserGroup {
  late String name;
  late String description;
  late List<String> areas; // where
  late List<bool> checked;
  late List<String> areasDescription;
  late Schedule schedule; // when
  late List<String> actions; // what
  late List<User> users; // who

  UserGroup(this.name, this.description, this.areas, this.schedule, this.actions, this.users, this.checked, this.areasDescription);
}

// This class replaces what we would get from a new http request to the server,
// asking for all the user groups, something like http://localhost:8080/get_user_groups
// that would return them as a string answer in JSON format
class Data {
  // Admin
  static Schedule scheduleAdmin = Schedule(
      [DateTime.monday, DateTime.tuesday, DateTime.wednesday, DateTime.thursday,
        DateTime.friday, DateTime.saturday, DateTime.sunday],
      DateTime(2023, 1, 1), DateTime(2026, 1, 1),
      TimeOfDay(hour: 0, minute: 0), TimeOfDay(hour: 23, minute: 59)
  );
  static UserGroup admin = UserGroup("admin", "administrators", ["building",],
    scheduleAdmin, Actions.all, [User("Ana", "89325"), User("Aureli", "87325"), ], [true, true, false, false, false],
    ["Opens an unlocked door", "Closes an open door", "Locks a door or all the doors in a room or group of rooms, if closed",
      "Unlocks a locked door or all the locked doors in an room", "Unlocks a door during 10 seconds and the locks it if it is closed"],
  );

  // Managers
  static Schedule scheduleManagers = Schedule(
      [DateTime.monday, DateTime.tuesday, DateTime.wednesday, DateTime.thursday,
        DateTime.friday, DateTime.saturday,],
      DateTime(2023, 9, 1), DateTime(2024, 8, 30),
      TimeOfDay(hour: 7, minute: 0), TimeOfDay(hour: 22, minute: 0)
  );
  static UserGroup managers = UserGroup("managers",
    "the CEO, CTO and heads of department", ["building",],
    scheduleManagers, Actions.all, [User("Manel", "43762"), User("Miquel", "77832"),
      User("Maria", "89324"), User("Maure", "12345"),], [true, true, false, false, false],
    ["Opens an unlocked door", "Closes an open door", "Locks a door or all the doors in a room or group of rooms, if closed",
      "Unlocks a locked door or all the locked doors in an room", "Unlocks a door during 10 seconds and the locks it if it is closed"],
  );

  // Employees
  static Schedule scheduleEmployees = Schedule(
      [DateTime.monday, DateTime.tuesday, DateTime.wednesday, DateTime.thursday,
        DateTime.friday,],
      DateTime(2023, 9, 1), DateTime(2024, 3, 1),
      TimeOfDay(hour: 7, minute: 0), TimeOfDay(hour: 20, minute: 0)
  );
  static UserGroup employees = UserGroup("employees",
    "employees of own departments plus oursourcing companies",
    ["ground_floor", "room3", "corridor"],
    scheduleEmployees, [Actions.open, Actions.close, Actions.unlockShortly], [User("Eva", "89325"), User("Eulalia", "87325"),
      User("Esteve", "43623"),], [true, true, false], ["Opens an unlocked door", "Closes an open door", "Unlocks a door during 10 seconds and the locks it if it is closed"],
  );

  static List<UserGroup> userGroups = [admin, managers, employees];

  // defaults for new user group
  static Schedule defaultSchedule = Schedule(
      [DateTime.monday, DateTime.tuesday, DateTime.wednesday, DateTime.thursday,
        DateTime.friday,],
      DateTime.now(), DateTime.now().add(const Duration(days: 365)),
      TimeOfDay(hour: 8, minute: 0), TimeOfDay(hour: 19, minute: 0)
  );
  static List<String> defaultAreas = ["ground_floor", "room3", "corridor"];
  static List<String> defaultActions = ["open", "close"];
  static String defaultName = "new group";
  static String defaultDescription = "";
  static List<String> defaultAreaDescription = ["Opens an unlocked door", "Closes an open door"];
  static Map<String, String> images = {
    'ana' : 'faces/ana.png',
    'aureli' : 'faces/aureli.png',
    'manel' : 'faces/manel.png',
    'miquel' : 'faces/miquel.png',
    'maria' : 'faces/maria.png',
    'maure' : 'faces/maure.png',
    'eva' : 'faces/eva.png',
    'eulalia' : 'faces/eulalia.png',
    'esteve' : 'faces/esteve.png',
    'new user': 'faces/new_user.png',
  };
}
