// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `English`
  String get buildingPageEnglish {
    return Intl.message(
      'English',
      name: 'buildingPageEnglish',
      desc: '',
      args: [],
    );
  }

  /// `Spanish`
  String get buildingPageSpanish {
    return Intl.message(
      'Spanish',
      name: 'buildingPageSpanish',
      desc: '',
      args: [],
    );
  }

  /// `Catalan`
  String get buildingPageCatalan {
    return Intl.message(
      'Catalan',
      name: 'buildingPageCatalan',
      desc: '',
      args: [],
    );
  }

  /// `S`
  String get spaceSymbol {
    return Intl.message(
      'S',
      name: 'spaceSymbol',
      desc: '',
      args: [],
    );
  }

  /// `P`
  String get partitionSymbol {
    return Intl.message(
      'P',
      name: 'partitionSymbol',
      desc: '',
      args: [],
    );
  }

  /// `Building`
  String get building {
    return Intl.message(
      'Building',
      name: 'building',
      desc: '',
      args: [],
    );
  }

  /// `Basement`
  String get basement {
    return Intl.message(
      'Basement',
      name: 'basement',
      desc: '',
      args: [],
    );
  }

  /// `Ground Floor`
  String get ground_floor {
    return Intl.message(
      'Ground Floor',
      name: 'ground_floor',
      desc: '',
      args: [],
    );
  }

  /// `First Floor`
  String get floor1 {
    return Intl.message(
      'First Floor',
      name: 'floor1',
      desc: '',
      args: [],
    );
  }

  /// `Stairs`
  String get stairs {
    return Intl.message(
      'Stairs',
      name: 'stairs',
      desc: '',
      args: [],
    );
  }

  /// `Exterior`
  String get exterior {
    return Intl.message(
      'Exterior',
      name: 'exterior',
      desc: '',
      args: [],
    );
  }

  /// `Parking`
  String get parking {
    return Intl.message(
      'Parking',
      name: 'parking',
      desc: '',
      args: [],
    );
  }

  /// `Hall`
  String get hall {
    return Intl.message(
      'Hall',
      name: 'hall',
      desc: '',
      args: [],
    );
  }

  /// `Room 1`
  String get room1 {
    return Intl.message(
      'Room 1',
      name: 'room1',
      desc: '',
      args: [],
    );
  }

  /// `Room 2`
  String get room2 {
    return Intl.message(
      'Room 2',
      name: 'room2',
      desc: '',
      args: [],
    );
  }

  /// `Room 3`
  String get room3 {
    return Intl.message(
      'Room 3',
      name: 'room3',
      desc: '',
      args: [],
    );
  }

  /// `Corridor`
  String get corridor {
    return Intl.message(
      'Corridor',
      name: 'corridor',
      desc: '',
      args: [],
    );
  }

  /// `IT`
  String get IT {
    return Intl.message(
      'IT',
      name: 'IT',
      desc: '',
      args: [],
    );
  }

  /// `D`
  String get doorSymbol {
    return Intl.message(
      'D',
      name: 'doorSymbol',
      desc: '',
      args: [],
    );
  }

  /// `locked`
  String get lockedName {
    return Intl.message(
      'locked',
      name: 'lockedName',
      desc: '',
      args: [],
    );
  }

  /// `unlocked`
  String get unlockedName {
    return Intl.message(
      'unlocked',
      name: 'unlockedName',
      desc: '',
      args: [],
    );
  }

  /// `true`
  String get trueName {
    return Intl.message(
      'true',
      name: 'trueName',
      desc: '',
      args: [],
    );
  }

  /// `false`
  String get falseName {
    return Intl.message(
      'false',
      name: 'falseName',
      desc: '',
      args: [],
    );
  }

  /// `The door has been opened successfully`
  String get doorOpened {
    return Intl.message(
      'The door has been opened successfully',
      name: 'doorOpened',
      desc: '',
      args: [],
    );
  }

  /// `The door has been closed successfully`
  String get doorClosed {
    return Intl.message(
      'The door has been closed successfully',
      name: 'doorClosed',
      desc: '',
      args: [],
    );
  }

  /// `Unable to make this action at this moment`
  String get errorAction {
    return Intl.message(
      'Unable to make this action at this moment',
      name: 'errorAction',
      desc: '',
      args: [],
    );
  }

  /// `The door has been locked successfully`
  String get doorLocked {
    return Intl.message(
      'The door has been locked successfully',
      name: 'doorLocked',
      desc: '',
      args: [],
    );
  }

  /// `The door has been unlocked successfully`
  String get doorUnlocked {
    return Intl.message(
      'The door has been unlocked successfully',
      name: 'doorUnlocked',
      desc: '',
      args: [],
    );
  }

  /// `Places`
  String get places {
    return Intl.message(
      'Places',
      name: 'places',
      desc: '',
      args: [],
    );
  }

  /// `Schedule`
  String get schedule {
    return Intl.message(
      'Schedule',
      name: 'schedule',
      desc: '',
      args: [],
    );
  }

  /// `Users`
  String get users {
    return Intl.message(
      'Users',
      name: 'users',
      desc: '',
      args: [],
    );
  }

  /// `Actions`
  String get actions {
    return Intl.message(
      'Actions',
      name: 'actions',
      desc: '',
      args: [],
    );
  }

  /// `Group`
  String get group {
    return Intl.message(
      'Group',
      name: 'group',
      desc: '',
      args: [],
    );
  }

  /// `Groups`
  String get groups {
    return Intl.message(
      'Groups',
      name: 'groups',
      desc: '',
      args: [],
    );
  }

  /// `Name group`
  String get groupName {
    return Intl.message(
      'Name group',
      name: 'groupName',
      desc: '',
      args: [],
    );
  }

  /// `User groups`
  String get groupUser {
    return Intl.message(
      'User groups',
      name: 'groupUser',
      desc: '',
      args: [],
    );
  }

  /// `Description`
  String get description {
    return Intl.message(
      'Description',
      name: 'description',
      desc: '',
      args: [],
    );
  }

  /// `Saved`
  String get saved {
    return Intl.message(
      'Saved',
      name: 'saved',
      desc: '',
      args: [],
    );
  }

  /// `Submit`
  String get submit {
    return Intl.message(
      'Submit',
      name: 'submit',
      desc: '',
      args: [],
    );
  }

  /// `new user`
  String get newUser {
    return Intl.message(
      'new user',
      name: 'newUser',
      desc: '',
      args: [],
    );
  }

  /// `From`
  String get from {
    return Intl.message(
      'From',
      name: 'from',
      desc: '',
      args: [],
    );
  }

  /// `To`
  String get to {
    return Intl.message(
      'To',
      name: 'to',
      desc: '',
      args: [],
    );
  }

  /// `Weekdays`
  String get weekdays {
    return Intl.message(
      'Weekdays',
      name: 'weekdays',
      desc: '',
      args: [],
    );
  }

  /// `Incorrect date. Try setting a start date that is smaller than the end date.`
  String get wrongDate {
    return Intl.message(
      'Incorrect date. Try setting a start date that is smaller than the end date.',
      name: 'wrongDate',
      desc: '',
      args: [],
    );
  }

  /// `Incorrect time. Try putting a lower starting time in the final`
  String get wrongHour {
    return Intl.message(
      'Incorrect time. Try putting a lower starting time in the final',
      name: 'wrongHour',
      desc: '',
      args: [],
    );
  }

  /// `Recent`
  String get recent {
    return Intl.message(
      'Recent',
      name: 'recent',
      desc: '',
      args: [],
    );
  }

  /// `Open`
  String get open {
    return Intl.message(
      'Open',
      name: 'open',
      desc: '',
      args: [],
    );
  }

  /// `Close`
  String get close {
    return Intl.message(
      'Close',
      name: 'close',
      desc: '',
      args: [],
    );
  }

  /// `Lock`
  String get lock {
    return Intl.message(
      'Lock',
      name: 'lock',
      desc: '',
      args: [],
    );
  }

  /// `Unlock`
  String get unlock {
    return Intl.message(
      'Unlock',
      name: 'unlock',
      desc: '',
      args: [],
    );
  }

  /// `Unlock shortly`
  String get unlock_shortly {
    return Intl.message(
      'Unlock shortly',
      name: 'unlock_shortly',
      desc: '',
      args: [],
    );
  }

  /// `Opens an unlocked door`
  String get open_description {
    return Intl.message(
      'Opens an unlocked door',
      name: 'open_description',
      desc: '',
      args: [],
    );
  }

  /// `Closes an open door`
  String get close_description {
    return Intl.message(
      'Closes an open door',
      name: 'close_description',
      desc: '',
      args: [],
    );
  }

  /// `Locks a door or all the doors in a room or group of rooms, if closed`
  String get lock_description {
    return Intl.message(
      'Locks a door or all the doors in a room or group of rooms, if closed',
      name: 'lock_description',
      desc: '',
      args: [],
    );
  }

  /// `Unlocks a locked door or all the locked doors in an room`
  String get unlock_description {
    return Intl.message(
      'Unlocks a locked door or all the locked doors in an room',
      name: 'unlock_description',
      desc: '',
      args: [],
    );
  }

  /// `Unlocks a door during 10 seconds and the locks it if it is closed`
  String get unlock_shortly_description {
    return Intl.message(
      'Unlocks a door during 10 seconds and the locks it if it is closed',
      name: 'unlock_shortly_description',
      desc: '',
      args: [],
    );
  }

  /// `new group`
  String get newGroup {
    return Intl.message(
      'new group',
      name: 'newGroup',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ca', countryCode: 'ES'),
      Locale.fromSubtags(languageCode: 'es', countryCode: 'ES'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
