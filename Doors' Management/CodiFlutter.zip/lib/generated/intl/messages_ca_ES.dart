// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ca_ES locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ca_ES';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "IT": MessageLookupByLibrary.simpleMessage("TI"),
        "actions": MessageLookupByLibrary.simpleMessage("Accions"),
        "basement": MessageLookupByLibrary.simpleMessage("Soterrani"),
        "building": MessageLookupByLibrary.simpleMessage("Edifici"),
        "buildingPageCatalan": MessageLookupByLibrary.simpleMessage("Català"),
        "buildingPageEnglish": MessageLookupByLibrary.simpleMessage("Anglès"),
        "buildingPageSpanish": MessageLookupByLibrary.simpleMessage("Castellà"),
        "close": MessageLookupByLibrary.simpleMessage("Tancar"),
        "close_description":
            MessageLookupByLibrary.simpleMessage("Tanca una porta oberta"),
        "corridor": MessageLookupByLibrary.simpleMessage("Passadís"),
        "description": MessageLookupByLibrary.simpleMessage("Descripció"),
        "doorClosed": MessageLookupByLibrary.simpleMessage(
            "La porta s\'ha tancat correctament"),
        "doorLocked": MessageLookupByLibrary.simpleMessage(
            "La porta s\'ha bloquejat correctament"),
        "doorOpened": MessageLookupByLibrary.simpleMessage(
            "La porta s\'ha obert correctament"),
        "doorSymbol": MessageLookupByLibrary.simpleMessage("Po"),
        "doorUnlocked": MessageLookupByLibrary.simpleMessage(
            "La porta s\'ha desbloquejat correctament"),
        "errorAction": MessageLookupByLibrary.simpleMessage(
            "No es pot realitzar aquesta acció en aquest moment"),
        "exterior": MessageLookupByLibrary.simpleMessage("Exterior"),
        "floor1": MessageLookupByLibrary.simpleMessage("Primera Planta"),
        "from": MessageLookupByLibrary.simpleMessage("Desde"),
        "ground_floor": MessageLookupByLibrary.simpleMessage("Planta Baixa"),
        "group": MessageLookupByLibrary.simpleMessage("Grup"),
        "groupName": MessageLookupByLibrary.simpleMessage("Nom del grup"),
        "groupUser": MessageLookupByLibrary.simpleMessage("Grups d\'usuaris"),
        "groups": MessageLookupByLibrary.simpleMessage("Grups"),
        "hall": MessageLookupByLibrary.simpleMessage("Vestíbul"),
        "lock": MessageLookupByLibrary.simpleMessage("Bloquejar"),
        "lock_description": MessageLookupByLibrary.simpleMessage(
            "Bloqueja una o totes les portes d\'una habitació o grup d\'aquestes, si estan tancades"),
        "lockedName": MessageLookupByLibrary.simpleMessage("bloquejada"),
        "newGroup": MessageLookupByLibrary.simpleMessage("nou grup"),
        "newUser": MessageLookupByLibrary.simpleMessage("nou usuari"),
        "open": MessageLookupByLibrary.simpleMessage("Obrir"),
        "open_description": MessageLookupByLibrary.simpleMessage(
            "Obre una porta desbloquejada"),
        "parking": MessageLookupByLibrary.simpleMessage("Pàrquing"),
        "partitionSymbol": MessageLookupByLibrary.simpleMessage("Pa"),
        "places": MessageLookupByLibrary.simpleMessage("Espais"),
        "recent": MessageLookupByLibrary.simpleMessage("Recents"),
        "room1": MessageLookupByLibrary.simpleMessage("Habitació 1"),
        "room2": MessageLookupByLibrary.simpleMessage("Habitació 2"),
        "room3": MessageLookupByLibrary.simpleMessage("Habitació 3"),
        "saved": MessageLookupByLibrary.simpleMessage("Guardat"),
        "schedule": MessageLookupByLibrary.simpleMessage("Horaris"),
        "spaceSymbol": MessageLookupByLibrary.simpleMessage("E"),
        "stairs": MessageLookupByLibrary.simpleMessage("Escales"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "to": MessageLookupByLibrary.simpleMessage("Fins"),
        "unlock": MessageLookupByLibrary.simpleMessage("Desbloquejar"),
        "unlock_description": MessageLookupByLibrary.simpleMessage(
            "Desbloqueja una o totes les portes en una habitació"),
        "unlock_shortly":
            MessageLookupByLibrary.simpleMessage("Desbloquejar temporalment"),
        "unlock_shortly_description": MessageLookupByLibrary.simpleMessage(
            "Desbloqueja una porta durant 10 segons. Llavors, la bloqueja si aquesta esta tancada"),
        "users": MessageLookupByLibrary.simpleMessage("Usuaris"),
        "weekdays": MessageLookupByLibrary.simpleMessage("Dies laborables"),
        "wrongDate": MessageLookupByLibrary.simpleMessage(
            "Data incorrecta. Prova de posar una data inicial menor a la final"),
        "wrongHour": MessageLookupByLibrary.simpleMessage(
            "Hora incorrecta. Prova de posar una hora inicial menor a la final")
      };
}
