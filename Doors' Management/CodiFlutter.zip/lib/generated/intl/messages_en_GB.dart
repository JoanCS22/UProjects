// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en_GB locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en_GB';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "IT": MessageLookupByLibrary.simpleMessage("IT"),
        "actions": MessageLookupByLibrary.simpleMessage("Actions"),
        "basement": MessageLookupByLibrary.simpleMessage("Basement"),
        "building": MessageLookupByLibrary.simpleMessage("Building"),
        "buildingPageCatalan": MessageLookupByLibrary.simpleMessage("Catalan"),
        "buildingPageEnglish": MessageLookupByLibrary.simpleMessage("English"),
        "buildingPageSpanish": MessageLookupByLibrary.simpleMessage("Spanish"),
        "close": MessageLookupByLibrary.simpleMessage("Close"),
        "close_description":
            MessageLookupByLibrary.simpleMessage("Closes an open door"),
        "corridor": MessageLookupByLibrary.simpleMessage("Corridor"),
        "description": MessageLookupByLibrary.simpleMessage("Description"),
        "doorClosed": MessageLookupByLibrary.simpleMessage(
            "The door has been closed successfully"),
        "doorLocked": MessageLookupByLibrary.simpleMessage(
            "The door has been locked successfully"),
        "doorOpened": MessageLookupByLibrary.simpleMessage(
            "The door has been opened successfully"),
        "doorSymbol": MessageLookupByLibrary.simpleMessage("D"),
        "doorUnlocked": MessageLookupByLibrary.simpleMessage(
            "The door has been unlocked successfully"),
        "errorAction": MessageLookupByLibrary.simpleMessage(
            "Unable to make this action at this moment"),
        "exterior": MessageLookupByLibrary.simpleMessage("Exterior"),
        "falseName": MessageLookupByLibrary.simpleMessage("false"),
        "floor1": MessageLookupByLibrary.simpleMessage("First Floor"),
        "from": MessageLookupByLibrary.simpleMessage("From"),
        "ground_floor": MessageLookupByLibrary.simpleMessage("Ground Floor"),
        "group": MessageLookupByLibrary.simpleMessage("Group"),
        "groupName": MessageLookupByLibrary.simpleMessage("Name group"),
        "groupUser": MessageLookupByLibrary.simpleMessage("User groups"),
        "groups": MessageLookupByLibrary.simpleMessage("Groups"),
        "hall": MessageLookupByLibrary.simpleMessage("Hall"),
        "lock": MessageLookupByLibrary.simpleMessage("Lock"),
        "lock_description": MessageLookupByLibrary.simpleMessage(
            "Locks a door or all the doors in a room or group of rooms, if closed"),
        "lockedName": MessageLookupByLibrary.simpleMessage("locked"),
        "newGroup": MessageLookupByLibrary.simpleMessage("new group"),
        "newUser": MessageLookupByLibrary.simpleMessage("new user"),
        "open": MessageLookupByLibrary.simpleMessage("Open"),
        "open_description":
            MessageLookupByLibrary.simpleMessage("Opens an unlocked door"),
        "parking": MessageLookupByLibrary.simpleMessage("Parking"),
        "partitionSymbol": MessageLookupByLibrary.simpleMessage("P"),
        "places": MessageLookupByLibrary.simpleMessage("Places"),
        "recent": MessageLookupByLibrary.simpleMessage("Recent"),
        "room1": MessageLookupByLibrary.simpleMessage("Room 1"),
        "room2": MessageLookupByLibrary.simpleMessage("Room 2"),
        "room3": MessageLookupByLibrary.simpleMessage("Room 3"),
        "saved": MessageLookupByLibrary.simpleMessage("Saved"),
        "schedule": MessageLookupByLibrary.simpleMessage("Schedule"),
        "spaceSymbol": MessageLookupByLibrary.simpleMessage("S"),
        "stairs": MessageLookupByLibrary.simpleMessage("Stairs"),
        "submit": MessageLookupByLibrary.simpleMessage("Submit"),
        "to": MessageLookupByLibrary.simpleMessage("To"),
        "trueName": MessageLookupByLibrary.simpleMessage("true"),
        "unlock": MessageLookupByLibrary.simpleMessage("Unlock"),
        "unlock_description": MessageLookupByLibrary.simpleMessage(
            "Unlocks a locked door or all the locked doors in an room"),
        "unlock_shortly":
            MessageLookupByLibrary.simpleMessage("Unlock shortly"),
        "unlock_shortly_description": MessageLookupByLibrary.simpleMessage(
            "Unlocks a door during 10 seconds and the locks it if it is closed"),
        "unlockedName": MessageLookupByLibrary.simpleMessage("unlocked"),
        "users": MessageLookupByLibrary.simpleMessage("Users"),
        "weekdays": MessageLookupByLibrary.simpleMessage("Weekdays"),
        "wrongDate": MessageLookupByLibrary.simpleMessage(
            "Incorrect date. Try setting a start date that is smaller than the end date."),
        "wrongHour": MessageLookupByLibrary.simpleMessage(
            "Incorrect time. Try putting a lower starting time in the final")
      };
}
