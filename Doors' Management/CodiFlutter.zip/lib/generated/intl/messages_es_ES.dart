// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a es_ES locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'es_ES';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "IT": MessageLookupByLibrary.simpleMessage("TI"),
        "actions": MessageLookupByLibrary.simpleMessage("Acciones"),
        "basement": MessageLookupByLibrary.simpleMessage("Subterraneo"),
        "building": MessageLookupByLibrary.simpleMessage("Edificio"),
        "buildingPageCatalan": MessageLookupByLibrary.simpleMessage("Catalán"),
        "buildingPageEnglish": MessageLookupByLibrary.simpleMessage("Inglés"),
        "buildingPageSpanish":
            MessageLookupByLibrary.simpleMessage("Castellano"),
        "close": MessageLookupByLibrary.simpleMessage("Cerrar"),
        "close_description":
            MessageLookupByLibrary.simpleMessage("Cierra una puerta abierta"),
        "corridor": MessageLookupByLibrary.simpleMessage("Pasillo"),
        "description": MessageLookupByLibrary.simpleMessage("Descripción"),
        "doorClosed": MessageLookupByLibrary.simpleMessage(
            "La puerta se ha cerrado correctamente"),
        "doorLocked": MessageLookupByLibrary.simpleMessage(
            "La puerta se ha bloqueado correctamente"),
        "doorOpened": MessageLookupByLibrary.simpleMessage(
            "La puerta se ha abierto correctamente"),
        "doorSymbol": MessageLookupByLibrary.simpleMessage("Pu"),
        "doorUnlocked": MessageLookupByLibrary.simpleMessage(
            "La puerta se ha desbloqueado correctamente"),
        "errorAction": MessageLookupByLibrary.simpleMessage(
            "No se puede realizar esa acción en este momento"),
        "exterior": MessageLookupByLibrary.simpleMessage("Exterior"),
        "falseName": MessageLookupByLibrary.simpleMessage("falso"),
        "floor1": MessageLookupByLibrary.simpleMessage("Primera Planta"),
        "from": MessageLookupByLibrary.simpleMessage("Desde"),
        "ground_floor": MessageLookupByLibrary.simpleMessage("Planta Baja"),
        "group": MessageLookupByLibrary.simpleMessage("Grupo"),
        "groupName": MessageLookupByLibrary.simpleMessage("Nombre del grupo"),
        "groupUser": MessageLookupByLibrary.simpleMessage("Grupos de usuarios"),
        "groups": MessageLookupByLibrary.simpleMessage("Grupos"),
        "hall": MessageLookupByLibrary.simpleMessage("Vestíbulo"),
        "lock": MessageLookupByLibrary.simpleMessage("Bloquear"),
        "lock_description": MessageLookupByLibrary.simpleMessage(
            "Bloquea una o todas las puertas de una habitación o conjunto de estas, si estan cerradas"),
        "lockedName": MessageLookupByLibrary.simpleMessage("bloqueada"),
        "newGroup": MessageLookupByLibrary.simpleMessage("nuevo grupo"),
        "newUser": MessageLookupByLibrary.simpleMessage("nuevo usuario"),
        "open": MessageLookupByLibrary.simpleMessage("Abrir"),
        "open_description": MessageLookupByLibrary.simpleMessage(
            "Abre una puerta desbloqueada"),
        "parking": MessageLookupByLibrary.simpleMessage("Párquing"),
        "partitionSymbol": MessageLookupByLibrary.simpleMessage("Pa"),
        "places": MessageLookupByLibrary.simpleMessage("Espacios"),
        "recent": MessageLookupByLibrary.simpleMessage("Recientes"),
        "room1": MessageLookupByLibrary.simpleMessage("Habitación 1"),
        "room2": MessageLookupByLibrary.simpleMessage("Habitación 2"),
        "room3": MessageLookupByLibrary.simpleMessage("Habitación 3"),
        "saved": MessageLookupByLibrary.simpleMessage("Guardado"),
        "schedule": MessageLookupByLibrary.simpleMessage("Horarios"),
        "spaceSymbol": MessageLookupByLibrary.simpleMessage("E"),
        "stairs": MessageLookupByLibrary.simpleMessage("Escaleras"),
        "submit": MessageLookupByLibrary.simpleMessage("Enviar"),
        "to": MessageLookupByLibrary.simpleMessage("Hasta"),
        "trueName": MessageLookupByLibrary.simpleMessage("cierto"),
        "unlock": MessageLookupByLibrary.simpleMessage("Desbloquear"),
        "unlock_description": MessageLookupByLibrary.simpleMessage(
            "Desbloquea una o todas las puertas de una habitación "),
        "unlock_shortly":
            MessageLookupByLibrary.simpleMessage("Desbloquear temporalmente"),
        "unlock_shortly_description": MessageLookupByLibrary.simpleMessage(
            "Desbloquea una puerta durante 10 segundos y la bloquea si esta cerrada"),
        "unlockedName": MessageLookupByLibrary.simpleMessage("desbloqueada"),
        "users": MessageLookupByLibrary.simpleMessage("Usuarios"),
        "weekdays": MessageLookupByLibrary.simpleMessage("Días laborables"),
        "wrongDate": MessageLookupByLibrary.simpleMessage(
            "Data incorrecta. Prueba a poner una data inicial menor que la final"),
        "wrongHour": MessageLookupByLibrary.simpleMessage(
            "Hora incorrecta. Prueba a poner una hora inicial menor que la final")
      };
}
