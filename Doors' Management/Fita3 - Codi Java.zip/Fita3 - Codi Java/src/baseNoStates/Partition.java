package baseNoStates;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

/*
Class Partition represents the different places in the building that contain
subareas. This class extends class Area and is part of Composite pattern.
 */
public class Partition extends Area {

  // List of subareas that form the partition
  final ArrayList<Area> areas = new ArrayList<>();

  public Partition(String id, String desc, Partition par) {
    super(id, desc, par);
  }

  @Override
  public ArrayList<Door> getDoorsGivingAccess() {
    return null;
  }


  @Override
  public void acceptVisitor(Visitor visitor) {
    visitor.visitPartition(this);
  }

  @Override
  public ArrayList<Area> getSpaces() {
    return areas;
  }

  @Override
  public String getId() {
    return areaId;
  }

  // Method that lets create children of this branch
  public void addSpace(Area a) {
    areas.add(a);
  }

  public JSONObject toJson(int depth) {
    // for depth=1 only the root and children,
    // for recusive = all levels use Integer.MAX_VALUE
    JSONObject json = new JSONObject();
    json.put("class", "partition");
    json.put("id", areaId);
    JSONArray jsonAreas = new JSONArray();
    if (depth > 0) {
      for (Area a : areas) {
        jsonAreas.put(a.toJson(depth - 1));
      }
      json.put("areas", jsonAreas);
    }
    return json;
  }
}
