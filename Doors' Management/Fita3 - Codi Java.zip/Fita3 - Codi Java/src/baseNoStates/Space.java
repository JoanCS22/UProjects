package baseNoStates;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

/*
Class Space represents places with doors. It extends class Area and
also forms Composite pattern.
 */
public class Space extends Area {

  // List of doors of current Space, they give access to another Space
  private final ArrayList<Door> doors = new ArrayList<>();

  public Space(String id, String desc, Partition par) {
    super(id, desc, par);
  }


  @Override
  public void acceptVisitor(Visitor visitor) {
    visitor.visitSpace(this);
  }

  @Override
  public ArrayList<Door> getDoorsGivingAccess() {
    return doors;
  }

  // It returns itself as a List, as it doesn't contain other spaces
  @Override
  public ArrayList<Area> getSpaces() {
    return new ArrayList<>(List.of(this));
  }

  @Override
  public String getId() {
    return areaId;
  }

  public void addDoor(Door d) {
    doors.add(d);
  }

  public JSONObject toJson(int depth) { // depth not used here
    JSONObject json = new JSONObject();
    json.put("class", "space");
    json.put("id", areaId);
    JSONArray jsonDoors = new JSONArray();
    for (Door d : getDoorsGivingAccess()) {
      jsonDoors.put(d.toJson());
    }
    json.put("access_doors", jsonDoors);
    return json;
  }
}
