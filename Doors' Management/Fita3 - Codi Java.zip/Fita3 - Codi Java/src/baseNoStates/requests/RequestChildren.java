package baseNoStates.requests;

import baseNoStates.Area;
import baseNoStates.DirectoryAreas;
import baseNoStates.FindAreaById;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RequestChildren implements Request {
    private final String areaId;
    private JSONObject jsonTree; // 1 level tree, root and children
    static Logger logger = LoggerFactory.getLogger("baseNoStates.RequestChildren");

    public RequestChildren(String areaId) {
        this.areaId = areaId;
    }

    public String getAreaId() {
        return areaId;
    }

    @Override
    public JSONObject answerToJson() {
        return jsonTree;
    }

    @Override
    public String toString() {
        return "RequestChildren{areaId=" + areaId + "}";
    }

    public void process() {
        FindAreaById areaById = new FindAreaById(areaId);
        DirectoryAreas.getUniqueInstance().acceptVisitor(areaById); //Area area = DirectoryAreas.getUniqueInstance().findAreaById(areaId);
        Area area = areaById.getArea();
        jsonTree = area.toJson(1);
        logger.debug("El codi entra a RequestChildren");
    }
}
