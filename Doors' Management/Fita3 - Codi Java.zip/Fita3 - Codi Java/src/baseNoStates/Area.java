package baseNoStates;

import java.util.ArrayList;
import org.json.JSONObject;

/*
Abstract class which represents a general area in the system,
extended by different places in the building: Partitions & Spaces.
Class needed to manage the user accesses to the different parts of the building.
It is part of Composite pattern: a Partition can have other partitions or Spaces as children.
 */

public abstract class Area {
  String areaId; // name
  String areaDescription;  // description
  Partition parent; // parent node

  public Area(String id, String desc, Partition par) {
    areaId = id;
    areaDescription = desc;
    parent = par;
  }

  //Returns the parent partition in the hierarchical structure of the building it belongs the area
  public Partition getParent() {
    return parent;
  }

  public abstract void acceptVisitor(Visitor visitor);

  public abstract ArrayList<Door> getDoorsGivingAccess();

  public abstract ArrayList<Area> getSpaces();

  public abstract String getId();

  public abstract JSONObject toJson(int depth);

  public Area findAreaById(String id) {
    if (id.equals("ROOT")) {
      // Special id that means that the wanted area is the root.
      // This is because the Flutter app client doesn't know the
      // id of the root, differently from the simulator
      return parent;
    } else {
      //...
    }
    return null;
  }
}
